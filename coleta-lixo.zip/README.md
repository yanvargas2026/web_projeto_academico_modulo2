# Coleta Lixo — Projeto Integrador II

Protótipo MVP de uma aplicação web para coleta de lixo eletrônico.
Desenvolvido em HTML, CSS e Vue.js.
